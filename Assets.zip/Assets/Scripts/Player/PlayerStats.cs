using UnityEngine;

public class PlayerStats : MonoBehaviour
{
    [Header("Base Stats")]
    [SerializeField] private float baseMaxHealth = 100f;
    [SerializeField] private float baseAttack = 10f;
    [SerializeField] private float baseSpeed = 5f;

    [Header("Current Stats")]
    private float currentMaxHealth;
    private float currentHealth;
    private float currentAttack;
    private float currentSpeed;

    private void Awake()
    {
        currentMaxHealth = baseMaxHealth;
        currentHealth = currentMaxHealth;
        currentAttack = baseAttack;
        currentSpeed = baseSpeed;
        
    }

    public void IncreaseMaxHealth(float amount)
    {
        currentMaxHealth += amount;
        currentHealth += amount;
        Debug.Log($"Max health increased by {amount}. New max: {currentMaxHealth}");
    }

    public void IncreaseAttack(float amount)
    {
        currentAttack += amount;
        Debug.Log($"Attack increased by {amount}. New attack: {currentAttack}");
    }


    public float GetCurrentHealth() => currentHealth;
    public float GetMaxHealth() => currentMaxHealth;
    public float GetAttack() => currentAttack;
    public float GetSpeed() => currentSpeed;

        private float speedBonus = 0f;
    
    public void IncreaseSpeed(float amount)
    {
        speedBonus += amount;
        // Notify PlayerMovement of the change
        PlayerMovement movement = GetComponent<PlayerMovement>();
        if (movement != null)
        {
            movement.ApplySpeedBoost(speedBonus);
        }
        Debug.Log($"Speed increased by {amount}. Total bonus: {speedBonus}");
    }
    
    public float GetSpeedBonus() => speedBonus;
}
