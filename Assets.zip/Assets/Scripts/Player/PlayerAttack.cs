using UnityEngine;

public class PlayerAttack : MonoBehaviour
{
    [Header("Attack Settings")]
    [SerializeField] private GameObject projectilePrefab;
    [SerializeField] private float projectileSpeed = 10f;
    [SerializeField] private float attackCooldown = 0.5f;
    [SerializeField] private Transform projectileSpawnPoint;
    
    private float nextAttackTime = 0f;
    private Vector2 lastDirection = Vector2.right; // Default facing direction

    void Update()
    {
        // Get movement input to determine facing direction
        Vector2 inputDirection = new Vector2(
            Input.GetAxisRaw("Horizontal"),
            Input.GetAxisRaw("Vertical")
        ).normalized;

        // Update last direction if there's any input
        if (inputDirection != Vector2.zero)
        {
            lastDirection = inputDirection;
        }

        // Attack when pressing the attack button (Space by default)
        if (Input.GetButtonDown("Fire1") && Time.time >= nextAttackTime)
        {
            ShootProjectile(lastDirection);
            nextAttackTime = Time.time + attackCooldown;
        }
    }

    private void ShootProjectile(Vector2 direction)
    {
        if (projectilePrefab == null) return;

        // Create projectile
        GameObject projectile = Instantiate(
            projectilePrefab, 
            projectileSpawnPoint.position, 
            Quaternion.identity
        );

        // Set projectile rotation to face movement direction
        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        projectile.transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);

        // Set projectile velocity
        Rigidbody2D rb = projectile.GetComponent<Rigidbody2D>();
        if (rb != null)
        {
            rb.linearVelocity = direction * projectileSpeed;
        }

        // Destroy projectile after some time (adjust as needed)
        Destroy(projectile, 2f);
    }
}