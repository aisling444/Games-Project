using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    [Header("Movement Settings")]
    [SerializeField] private float baseMoveSpeed = 5f;
    private float currentMoveSpeed;
    
    private Rigidbody2D rb;
    private Vector2 movement;
    private Door currentDoor;
    
    // Reference to PlayerStats for power-up effects
    private PlayerStats playerStats;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        playerStats = GetComponent<PlayerStats>();
        currentMoveSpeed = baseMoveSpeed;
        
        // Initialize with any existing speed upgrades
        if (playerStats != null)
        {
            currentMoveSpeed = baseMoveSpeed + playerStats.GetSpeedBonus();
        }
    }

    void Update()
    {
        // Get input
        movement.x = Input.GetAxisRaw("Horizontal");
        movement.y = Input.GetAxisRaw("Vertical");

        // Detect interaction with doors
        if (Input.GetKeyDown(KeyCode.E) && currentDoor != null)
        {
            InteractWithDoor();
        }
    }

    void FixedUpdate()
    {
        // Move the player with current speed
        rb.MovePosition(rb.position + movement.normalized * currentMoveSpeed * Time.fixedDeltaTime);
    }

    // Call this method when speed power-up is collected
    public void ApplySpeedBoost(float boostAmount)
    {
        currentMoveSpeed = baseMoveSpeed + boostAmount;
        Debug.Log($"Speed boosted! New speed: {currentMoveSpeed}");
    }

    // Reset to base speed (if needed)
    public void ResetSpeed()
    {
        currentMoveSpeed = baseMoveSpeed;
    }

    // This method is called when the player interacts with a door
    void InteractWithDoor()
    {
        if (currentDoor != null)
        {
            Vector2Int direction = Vector2Int.zero;
            
            if (movement.x > 0) direction = Vector2Int.right;
            else if (movement.x < 0) direction = Vector2Int.left;
            else if (movement.y > 0) direction = Vector2Int.up;
            else if (movement.y < 0) direction = Vector2Int.down;

            Vector2Int newRoomIndex = currentDoor.GetNewRoomIndex(direction);
            RoomManager.Instance.LoadNewRoom(newRoomIndex);
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        Door door = other.GetComponent<Door>();
        if (door != null)
        {
            currentDoor = door;
        }
    }

    void OnTriggerExit2D(Collider2D other)
    {
        if (other.GetComponent<Door>() != null)
        {
            currentDoor = null;
        }
    }
}