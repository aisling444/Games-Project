using UnityEngine;

public class Door : MonoBehaviour
{
    // This method now checks for the x and y components of the direction
    public Vector2Int GetNewRoomIndex(Vector2Int direction)
    {
        Room currentRoom = GetComponentInParent<Room>();  // Get the room the door is part of
        Vector2Int currentRoomIndex = currentRoom.RoomIndex;

        if (direction == Vector2Int.up)
        {
            return new Vector2Int(currentRoomIndex.x, currentRoomIndex.y + 1);  // Move up
        }
        else if (direction == Vector2Int.down)
        {
            return new Vector2Int(currentRoomIndex.x, currentRoomIndex.y - 1);  // Move down
        }
        else if (direction == Vector2Int.left)
        {
            return new Vector2Int(currentRoomIndex.x - 1, currentRoomIndex.y);  // Move left
        }
        else if (direction == Vector2Int.right)
        {
            return new Vector2Int(currentRoomIndex.x + 1, currentRoomIndex.y);  // Move right
        }
        else
        {
            return currentRoomIndex;  // Default to current room if no valid direction is given
        }
    }
}
