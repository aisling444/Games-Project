using UnityEngine;

public class DoorTrigger : MonoBehaviour
{
    public Vector2Int direction;
    
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            RoomManager.Instance.LoadNewRoom(GetNewRoomIndex());
        }
    }

    private Vector2Int GetNewRoomIndex()
    {
        Room currentRoom = GetComponentInParent<Room>();
        return currentRoom.RoomIndex + direction;
    }
}