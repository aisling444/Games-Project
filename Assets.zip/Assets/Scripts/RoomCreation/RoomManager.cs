using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RoomManager : MonoBehaviour
{
    public static RoomManager Instance;

    [Header("Prefabs")]
    [SerializeField] private GameObject playerPrefab;
    [SerializeField] private GameObject roomPrefab;
    
    [Header("Generation Settings")]
    [SerializeField] private int maxRooms = 15;
    [SerializeField] private int minRooms = 10;
    [SerializeField] private int roomWidth = 20;
    [SerializeField] private int roomHeight = 12;
    [SerializeField] private int gridSizeX = 10;
    [SerializeField] private int gridSizeY = 10;

    [Header("References")]
    [SerializeField] private Camera mainCamera;
    [SerializeField] private float cameraTransitionSpeed = 5f;

    [Header("Enemy Settings")]
    [SerializeField] private EnemyManager enemyManager;

    private List<GameObject> roomObjects = new List<GameObject>();
    private Queue<Vector2Int> roomQueue = new Queue<Vector2Int>();
    private int[,] roomGrid;
    private int roomCount;
    private bool generationComplete = false;
    private GameObject currentActiveRoom;
    private GameObject playerInstance;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        roomGrid = new int[gridSizeX, gridSizeY];
        roomQueue = new Queue<Vector2Int>();
        Vector2Int initialRoomIndex = new Vector2Int(gridSizeX / 2, gridSizeY / 2);
        StartRoomGenerationFromRoom(initialRoomIndex);
    }

    private void Update()
    {
        if (roomQueue.Count > 0 && roomCount < maxRooms && !generationComplete)
        {
            Vector2Int roomIndex = roomQueue.Dequeue();
            TryGenerateRoom(new Vector2Int(roomIndex.x - 1, roomIndex.y));
            TryGenerateRoom(new Vector2Int(roomIndex.x + 1, roomIndex.y));
            TryGenerateRoom(new Vector2Int(roomIndex.x, roomIndex.y + 1));
            TryGenerateRoom(new Vector2Int(roomIndex.x, roomIndex.y - 1));
        }
        else if (roomCount < minRooms)
        {
            Debug.Log("Room count was less than minimum. Regenerating...");
            RegenerateRooms();
        }
        else if (!generationComplete)
        {
            Debug.Log($"Generation complete, {roomCount} rooms created");
            AssignSpecialRooms();
            generationComplete = true;
        }
    }

    private void StartRoomGenerationFromRoom(Vector2Int roomIndex)
    {
        roomQueue.Enqueue(roomIndex);
        roomGrid[roomIndex.x, roomIndex.y] = 1;
        roomCount++;

        var initialRoom = Instantiate(roomPrefab, GetPositionFromGridIndex(roomIndex), Quaternion.identity);
        initialRoom.name = $"Room-{roomIndex.x},{roomIndex.y}";
        roomObjects.Add(initialRoom);

        Room roomScript = initialRoom.GetComponent<Room>();
        roomScript.InitializeRoom(roomIndex, RoomType.Spawn);
        roomScript.SetUpDoors();

        currentActiveRoom = initialRoom;
    }

    private bool TryGenerateRoom(Vector2Int roomIndex)
    {
        if (roomIndex.x >= gridSizeX || roomIndex.y >= gridSizeY || 
            roomIndex.x < 0 || roomIndex.y < 0 || 
            roomGrid[roomIndex.x, roomIndex.y] != 0 || 
            roomCount >= maxRooms || 
            Random.value < 0.5f || 
            CountAdjacentRooms(roomIndex) > 1)
        {
            return false;
        }

        roomQueue.Enqueue(roomIndex);
        roomGrid[roomIndex.x, roomIndex.y] = 1;
        roomCount++;

        var newRoom = Instantiate(roomPrefab, GetPositionFromGridIndex(roomIndex), Quaternion.identity);
        newRoom.name = $"Room-{roomIndex.x},{roomIndex.y}";
        newRoom.SetActive(false); // Start with room deactivated
        roomObjects.Add(newRoom);

        Room roomScript = newRoom.GetComponent<Room>();
        roomScript.InitializeRoom(roomIndex, RoomType.Normal);
        roomScript.SetUpDoors();

        OpenDoors(newRoom, roomIndex.x, roomIndex.y);
        return true;
    }

    private void AssignSpecialRooms()
    {
    if (roomObjects.Count == 0) return;

    // Set spawn room
    Room spawnRoom = roomObjects[0].GetComponent<Room>();
    spawnRoom.roomType = RoomType.Spawn;
    spawnRoom.ApplyRoomTypeVisuals();
    spawnRoom.gameObject.name = "SpawnRoom";
    currentActiveRoom = spawnRoom.gameObject;

    // Spawn player
    if (playerPrefab != null)
    {
        Vector3 spawnPosition = GetPositionFromGridIndex(spawnRoom.RoomIndex);
        playerInstance = Instantiate(playerPrefab, spawnPosition, Quaternion.identity);
        Debug.Log("Player spawned in spawn room");
    }
    else
    {
        Debug.LogError("Player prefab not assigned in RoomManager!");
    }

    // Set boss room
    Room bossRoom = FindFarthestRoom(spawnRoom.RoomIndex);
    if (bossRoom != null)
    {
        bossRoom.roomType = RoomType.Boss;
        bossRoom.ApplyRoomTypeVisuals();
        bossRoom.gameObject.name = "BossRoom";
    }

    // Spawn enemies in all other rooms
    foreach (var roomObj in roomObjects)
    {
        Room room = roomObj.GetComponent<Room>();
        if (room.roomType == RoomType.Normal && enemyManager != null)
        {
            enemyManager.SpawnEnemiesInRoom(room);
        }
    }
    }


    public void LoadNewRoom(Vector2Int newRoomIndex)
    {
        GameObject newRoom = GetRoomAt(newRoomIndex);
        if (newRoom == null)
        {
            Debug.LogWarning($"Room at {newRoomIndex} doesn't exist!");
            return;
        }

        StartCoroutine(TransitionToRoom(newRoom, newRoomIndex));
    }

    private IEnumerator TransitionToRoom(GameObject newRoom, Vector2Int newRoomIndex)
    {
        // Optional: Add transition effects here
        
        // Deactivate current room
        if (currentActiveRoom != null)
        {
            currentActiveRoom.SetActive(false);
        }

        // Activate new room
        newRoom.SetActive(true);
        currentActiveRoom = newRoom;

        // Move player
        MovePlayerToRoomEntry(newRoomIndex);

        // Move camera
        if (mainCamera != null)
        {
            Vector3 targetPosition = GetPositionFromGridIndex(newRoomIndex);
            targetPosition.z = mainCamera.transform.position.z;
            
            while (Vector3.Distance(mainCamera.transform.position, targetPosition) > 0.1f)
            {
                mainCamera.transform.position = Vector3.Lerp(
                    mainCamera.transform.position, 
                    targetPosition, 
                    cameraTransitionSpeed * Time.deltaTime);
                yield return null;
            }
        }

        // Notify room it's been entered
        Room roomScript = newRoom.GetComponent<Room>();
        if (roomScript != null)
        {
            roomScript.OnRoomEnter();
        }
    }

    private void MovePlayerToRoomEntry(Vector2Int newRoomIndex)
    {
        if (playerInstance == null) return;

        // Basic implementation - move to center
        playerInstance.transform.position = GetPositionFromGridIndex(newRoomIndex);

        // Advanced: Could adjust position based on entry direction
    }

    private Room FindFarthestRoom(Vector2Int startRoom)
    {
        Room farthestRoom = null;
        float maxDistance = 0f;

        foreach (var roomObj in roomObjects)
        {
            Room room = roomObj.GetComponent<Room>();
            float distance = Vector2Int.Distance(startRoom, room.RoomIndex);

            if (distance > maxDistance && room.roomType != RoomType.Spawn)
            {
                maxDistance = distance;
                farthestRoom = room;
            }
        }
        return farthestRoom;
    }

    private void RegenerateRooms()
    {
        foreach (var room in roomObjects)
        {
            Destroy(room);
        }
        roomObjects.Clear();
        roomGrid = new int[gridSizeX, gridSizeY];
        roomQueue.Clear();
        roomCount = 0;
        generationComplete = false;

        StartRoomGenerationFromRoom(new Vector2Int(gridSizeX / 2, gridSizeY / 2));
    }

    private void OpenDoors(GameObject room, int x, int y)
    {
        Room newRoomScript = room.GetComponent<Room>();

        Room leftRoomScript = GetRoomScriptAt(new Vector2Int(x - 1, y));
        Room rightRoomScript = GetRoomScriptAt(new Vector2Int(x + 1, y));
        Room topRoomScript = GetRoomScriptAt(new Vector2Int(x, y + 1));
        Room bottomRoomScript = GetRoomScriptAt(new Vector2Int(x, y - 1));

        if (leftRoomScript != null)
        {
            newRoomScript.OpenDoor(Vector2Int.left);
            leftRoomScript.OpenDoor(Vector2Int.right);
        }

        if (rightRoomScript != null)
        {
            newRoomScript.OpenDoor(Vector2Int.right);
            rightRoomScript.OpenDoor(Vector2Int.left);
        }

        if (topRoomScript != null)
        {
            newRoomScript.OpenDoor(Vector2Int.up);
            topRoomScript.OpenDoor(Vector2Int.down);
        }

        if (bottomRoomScript != null)
        {
            newRoomScript.OpenDoor(Vector2Int.down);
            bottomRoomScript.OpenDoor(Vector2Int.up);
        }
    }

    private Room GetRoomScriptAt(Vector2Int index)
    {
        GameObject roomObject = roomObjects.Find(r => 
            r.GetComponent<Room>().RoomIndex == index);
        return roomObject?.GetComponent<Room>();
    }

    private int CountAdjacentRooms(Vector2Int roomIndex)
    {
        int count = 0;
        if (roomIndex.x > 0 && roomGrid[roomIndex.x - 1, roomIndex.y] != 0) count++;
        if (roomIndex.x < gridSizeX - 1 && roomGrid[roomIndex.x + 1, roomIndex.y] != 0) count++;
        if (roomIndex.y > 0 && roomGrid[roomIndex.x, roomIndex.y - 1] != 0) count++;
        if (roomIndex.y < gridSizeY - 1 && roomGrid[roomIndex.x, roomIndex.y + 1] != 0) count++;
        return count;
    }

    public Vector3 GetPositionFromGridIndex(Vector2Int gridIndex)
    {
        return new Vector3(
            roomWidth * (gridIndex.x - gridSizeX / 2), 
            roomHeight * (gridIndex.y - gridSizeY / 2), 
            0);
    }

    public GameObject GetRoomAt(Vector2Int roomIndex)
    {
        return roomObjects.Find(room => 
            room.GetComponent<Room>().RoomIndex == roomIndex);
    }

    public GameObject GetCurrentRoom()
    {
        return currentActiveRoom;
    }
}