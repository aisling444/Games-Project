using UnityEngine;

public enum RoomType { Normal, Spawn, Boss }

public class Room : MonoBehaviour
{
    public Sprite topWallSprite;
    public Sprite bottomWallSprite;
    public Sprite leftWallSprite;
    public Sprite rightWallSprite;

    [SerializeField] private GameObject TopDoor;
    [SerializeField] private GameObject BotDoor;
    [SerializeField] private GameObject LeftDoor;
    [SerializeField] private GameObject RightDoor;

    public Vector2Int RoomIndex { get; set; }
    public RoomType roomType = RoomType.Normal;

    public void InitializeRoom(Vector2Int index, RoomType type)
    {
        RoomIndex = index;
        roomType = type;
        ApplyRoomTypeVisuals();
    }

    public void OpenDoor(Vector2Int direction)
    {
        if (direction == Vector2Int.up) TopDoor.SetActive(true);
        if (direction == Vector2Int.down) BotDoor.SetActive(true);
        if (direction == Vector2Int.left) LeftDoor.SetActive(true);
        if (direction == Vector2Int.right) RightDoor.SetActive(true);
    }

    public void SetUpDoors() 
    {
        SetDoorTrigger(TopDoor);
        SetDoorTrigger(BotDoor);
        SetDoorTrigger(LeftDoor);
        SetDoorTrigger(RightDoor);
    }

    private void SetDoorTrigger(GameObject door)
    {
        if (door != null)
        {
            var collider = door.GetComponent<Collider2D>();
            if (collider != null) collider.isTrigger = true;
        }
    }

    public void ApplyRoomTypeVisuals()
    {
        SpriteRenderer sr = GetComponent<SpriteRenderer>();
        if (sr != null)
        {
            switch (roomType)
            {
                case RoomType.Spawn:
                    sr.color = Color.green;
                    break;
                case RoomType.Boss:
                    sr.color = Color.red;
                    break;
                case RoomType.Normal:
                default:
                    sr.color = Color.white;
                    break;
            }
        }
    }

    // The new OnRoomEnter method
    public void OnRoomEnter()
    {
        // You can add logic here to trigger special actions when the player enters the room
        Debug.Log($"Player entered room at {RoomIndex}.");

        // For example, if this is the Boss room, you could trigger a boss fight
        if (roomType == RoomType.Boss)
        {
            Debug.Log("This is the boss room! Prepare for battle.");
        }
        else if (roomType == RoomType.Spawn)
        {
            Debug.Log("Welcome to the spawn room.");
        }
    }
}
