using UnityEngine;

public class UpgradeItem : MonoBehaviour
{
    [SerializeField] private EnemyManager.StatUpgradeItem.UpgradeType upgradeType;
    [SerializeField] private float upgradeValue;
    
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            ApplyUpgrade(other.gameObject);
            Destroy(gameObject);
        }
    }

    private void ApplyUpgrade(GameObject player)
    {
        PlayerStats stats = player.GetComponent<PlayerStats>();
        if (stats == null) return;

        switch (upgradeType)
        {
            case EnemyManager.StatUpgradeItem.UpgradeType.Health:
                stats.IncreaseMaxHealth(upgradeValue);
                break;
            case EnemyManager.StatUpgradeItem.UpgradeType.Attack:
                stats.IncreaseAttack(upgradeValue);
                break;
            case EnemyManager.StatUpgradeItem.UpgradeType.Speed:
                stats.IncreaseSpeed(upgradeValue);
                break;
        }
    }
}