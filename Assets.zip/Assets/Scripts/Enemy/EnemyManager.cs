using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyManager : MonoBehaviour
{

    [System.Serializable]
    public class EnemyType
    {
        public GameObject prefab;
        public int minCount = 1;
        public int maxCount = 3;
        [Range(0f, 1f)] public float spawnChance = 0.7f;
        public int weight = 1; // Higher weight = more likely to spawn
    }

    [System.Serializable]
    public class StatUpgradeItem
    {
        public GameObject prefab;
        public enum UpgradeType { Health, Attack, Speed }
        public UpgradeType upgradeType;
        public float upgradeValue;
        [Range(0f, 1f)] public float dropChance = 0.3f;
    }

    [Header("Enemy Settings")]
    [SerializeField] private List<EnemyType> enemyTypes = new List<EnemyType>();
    [SerializeField] private float spawnRadius = 5f;

    [Header("Upgrade Items")]
    [SerializeField] private List<StatUpgradeItem> upgradeItems = new List<StatUpgradeItem>();

    public void SpawnEnemiesInRoom(Room room)
    {
        if (room.roomType == RoomType.Spawn || room.roomType == RoomType.Boss) return;

        // First determine if we should spawn any enemies at all
        if (Random.value > 0.8f) return; // 20% chance for empty room

        // Calculate total weight for all enemy types
        int totalWeight = 0;
        foreach (var enemyType in enemyTypes)
        {
            totalWeight += enemyType.weight;
        }

        // Determine how many enemy groups to spawn (1-3 different types)
        int enemyGroups = Random.Range(1, 4);
        
        for (int i = 0; i < enemyGroups; i++)
        {
            SpawnRandomEnemyGroup(room, totalWeight);
        }
    }

        private void SpawnRandomEnemyGroup(Room room, int totalWeight)
    {
        // Get random enemy type based on weight
        EnemyType enemyType = GetRandomEnemyType(totalWeight);
        
        if (enemyType == null || Random.value > enemyType.spawnChance) return;

        int enemyCount = Random.Range(enemyType.minCount, enemyType.maxCount + 1);
        for (int i = 0; i < enemyCount; i++)
        {
            Vector2 randomPos = (Vector2)room.transform.position + 
                              Random.insideUnitCircle * spawnRadius;
            GameObject enemy = Instantiate(enemyType.prefab, randomPos, 
                                         Quaternion.identity, room.transform);
            
            EnemyHealth enemyHealth = enemy.GetComponent<EnemyHealth>();
            if (enemyHealth != null)
            {
                enemyHealth.OnDeath += () => TryDropUpgradeItem(enemy.transform.position);
            }
        }
    }

     private EnemyType GetRandomEnemyType(int totalWeight)
    {
        if (enemyTypes.Count == 0 || totalWeight <= 0) return null;

        int randomWeight = Random.Range(0, totalWeight);
        int currentWeight = 0;

        foreach (var enemyType in enemyTypes)
        {
            currentWeight += enemyType.weight;
            if (randomWeight < currentWeight)
            {
                return enemyType;
            }
        }

        return enemyTypes[0]; // fallback
    }


    private void TryDropUpgradeItem(Vector3 position)
    {
        foreach (var item in upgradeItems)
        {
            if (Random.value <= item.dropChance)
            {
                Instantiate(item.prefab, position, Quaternion.identity);
                break; // Only drop one item per enemy
            }
        }
    }
}